# QuantumPINN Lab

**A research-oriented 1D quantum-mechanics workbench** combining a physics-informed neural network (PINN), a finite-difference reference solver, real-time wavepacket propagation, and a qubit Hamiltonian bridge.

> **Status:** research prototype / educational software (v0.1.0). The code uses dimensionless units and 1D model potentials. It is not yet a validated device-design package for a real semiconductor, molecule, or quantum processor.

## What is included

| Module | Capability |
|---|---|
| Stationary PINN | Approximate the low-lying eigenfunctions and energies of `[-½ d²/dx² + V(x)] ψ = Eψ` |
| Physics-informed loss | Schrödinger residual, normalization, excited-state orthogonality, weak energy anchor |
| Exact boundary condition | Trial function is multiplied by `1 - ξ²`, so ψ is zero at both domain endpoints |
| Validation | SciPy tridiagonal finite-difference eigensolver; energy, residual, norm and orthogonality checks |
| Potential library | Free, harmonic, quartic, double well, finite square well, Gaussian well, square barrier, softened Coulomb |
| Observables | Position/momentum expectations, uncertainties, kinetic/potential/total energy |
| Time dynamics | Crank–Nicolson propagation of a Gaussian wavepacket; probability density/current and norm drift |
| Quantum-computing bridge | Pauli expansion of a finite-grid Hamiltonian; optional Qiskit `SparsePauliOp` adapter |
| Interfaces | Streamlit dashboard and command-line runner |

## Architecture

```text
                 ┌────────────────────────────────┐
                 │         User interfaces        │
                 │    Streamlit UI  |  CLI        │
                 └───────────────┬────────────────┘
                                 │
                 ┌───────────────▼────────────────┐
                 │       Application services    │
                 │ stationary solve / dynamics   │
                 │ export / diagnostics           │
                 └───────┬─────────────┬──────────┘
                         │             │
           ┌─────────────▼──────┐  ┌───▼────────────────┐
           │ PINN engine        │  │ Numerical physics  │
           │ PyTorch MLP        │  │ SciPy FD eigensolve│
           │ autograd d²ψ/dx²   │  │ Crank–Nicolson TDSE│
           │ physics loss       │  │ observables        │
           └─────────────┬──────┘  └──────┬─────────────┘
                         │                │
                         └───────┬────────┘
                                 │
                  ┌──────────────▼──────────────┐
                  │       Quantum bridge       │
                  │ grid Hamiltonian → Pauli   │
                  │ terms → optional Qiskit    │
                  └─────────────────────────────┘
```

### Repository map

```text
quantum-pinn-lab/
├── quantum_pinn/
│   ├── config.py                  # domain and PINN configuration
│   ├── models/pinn.py             # boundary-constrained tanh MLP
│   ├── physics/
│   │   ├── potentials.py          # model potentials (NumPy + PyTorch)
│   │   ├── reference.py           # finite-difference eigenvalue baseline
│   │   ├── observables.py         # expectation values and uncertainties
│   │   └── dynamics.py            # Crank–Nicolson time evolution
│   ├── solvers/stationary.py      # sequential PINN training and diagnostics
│   ├── quantum/pauli.py           # matrix-to-Pauli / Qiskit adapter
│   ├── cli.py                     # command-line entry point
│   └── ui/app.py                  # Streamlit workbench
├── PROJECT_PLAN.md                # research plan and milestones
├── tests/                         # physics and quantum-bridge tests
├── examples/                      # small runnable examples
├── outputs/                       # generated result files
├── ARCHITECTURE.md
├── pyproject.toml
└── requirements.txt
```

## Physics and numerical conventions

The code solves the dimensionless stationary equation

\[
\left[-\frac{1}{2}\frac{d^2}{dx^2}+V(x)\right]\psi_n(x)=E_n\psi_n(x),
\qquad x\in[x_{\min},x_{\max}],
\]

with Dirichlet boundaries `ψ(xmin)=ψ(xmax)=0`. Dimensionless units set `ℏ = m = 1`. The time-dependent solver uses

\[
i\frac{\partial\psi}{\partial t}=\left[-\frac{1}{2}\frac{\partial^2}{\partial x^2}+V(x)\right]\psi.
\]

This is a modeling convention, not a conversion to SI units. A real device model must specify material parameters, effective mass, length and energy scales, interfaces, and boundary conditions.

### PINN strategy

For each state, a neural trial function is fitted to the corresponding finite-difference eigenvector (optional warm start), then refined by minimizing

\[
\mathcal L = \underbrace{\langle |H\psi-E\psi|^2\rangle}_{\mathcal L_{PDE}}
 +\lambda_N(\|\psi\|_2^2-1)^2
 +\lambda_O\sum_{j<n}|\langle\psi_j|\psi\rangle|^2
 +\lambda_E(E-E_{FD})^2.
\]

The first term uses PyTorch autograd to obtain the second spatial derivative. Normalization and overlaps are evaluated by numerical quadrature. The weak energy anchor helps prevent drift during this prototype's fine-tuning phase.

**Why a warm start?** Excited-state PINNs can collapse to lower eigenstates or converge to the wrong mode. The FD warm start makes the demonstration more robust and also gives a direct validation baseline. Disable it to use a genuinely reference-free training objective: random network weights, a potential-scale energy initialization, and no FD energy anchor. The FD solver still runs separately to report validation metrics after training. This option is harder to converge, especially for excited states. The default is a **hybrid PINN refinement workflow**.

## Installation

Recommended environment on Windows: **64-bit Python 3.12**. The current SciPy/NumPy requirements need Python 3.12 or newer, while the PyTorch Windows installation documentation currently lists Python 3.9–3.12. Python 3.13–3.15 may work with published wheels, but use 3.12 for the most conservative documented Windows setup. Create a fresh virtual environment; do not reuse an environment that has incompatible scientific packages installed.

### Windows PowerShell

```powershell
cd quantum-pinn-lab
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -e .
```

If the `py -3.13` launcher is unavailable, install a supported 64-bit Python version and use `python -m venv .venv` instead.

### macOS / Linux

```bash
cd quantum-pinn-lab
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -e .
```

### Optional Qiskit integration

```bash
pip install -e '.[quantum]'
```

The base Pauli decomposition works without Qiskit. Qiskit is only needed when converting the terms into a `SparsePauliOp` object.

### GPU note

The project auto-selects CUDA when PyTorch detects a compatible NVIDIA setup; otherwise it runs on CPU. Install the PyTorch build matching your installed NVIDIA driver/CUDA runtime using the official PyTorch install selector. A 4 GB GPU can run the small 1D models, but use a modest network width (32 or 64), 128–256 collocation points and one or two eigenstates if memory is tight. CPU mode is perfectly adequate for initial tests.

## Run the application

```bash
streamlit run quantum_pinn/ui/app.py
```

Open the local URL printed by Streamlit.

## Run from the command line

```bash
python -m quantum_pinn.cli --potential harmonic --states 3 --epochs 500 --pretrain-steps 300
```

Other examples:

```bash
python -m quantum_pinn.cli --potential double_well --states 3 --barrier 0.7 --separation 1.3
python -m quantum_pinn.cli --potential finite_well --states 4 --depth 10 --width 2.5
python -m quantum_pinn.cli --potential gaussian_well --states 2 --depth 7 --sigma 0.8 --device cpu
```

Results are saved to `outputs/stationary_result.npz` and `outputs/summary.json`.

## Run tests

```bash
pip install -e '.[dev]'
pytest
```

## Recommended experiment sequence

1. **Harmonic oscillator:** compare the first few energies with the analytic dimensionless result `E_n = n + 1/2` when the domain is sufficiently wide. Confirm node count and parity.
2. **Double well:** vary the separation and barrier. Track the low-energy splitting between the nearly symmetric/antisymmetric pair.
3. **Finite well:** vary depth and width; check the bound-state count and wavefunction leakage into the outside region.
4. **Barrier tunneling:** launch a Gaussian packet from one side and examine transmitted/reflected probability and norm conservation.
5. **Quantum mapping:** increase qubit count from 2 to 5; inspect Pauli-term count and reconstruction error.
6. **Convergence study:** repeat with increasing grid sizes, collocation counts, domain widths and random seeds. Report mean/std energy error, residual and norm drift.

## How to interpret results

Do not use one training loss as the sole success criterion. A credible run should show all of the following:

- Energy error against the FD reference is stable under grid refinement.
- `∫ |ψ|² dx` is close to one.
- Reference-state fidelity and node count are physically sensible.
- Pairwise overlaps are close to zero for distinct states.
- The strong-form residual is small on a **separate dense diagnostic grid**.
- The expected number of nodes and parity are physically sensible.
- Time-dependent norm drift remains small when `dt` and `dx` are refined.
- Pauli reconstruction error is small relative to the Hamiltonian norm.

## Roadmap beyond v0.1

- Adaptive residual-based collocation and curriculum training.
- Domain-decomposed PINNs for discontinuous material interfaces.
- Inverse quantum design: infer potential parameters from target spectra.
- Parameter-conditioned surrogate network for rapid sweeps across potential families.
- 2D quantum dots and finite-element reference solvers.
- Time-dependent PINNs and open-system Lindblad dynamics.
- VQE/QAOA-style experiments on the Pauli Hamiltonian; hardware execution only after measurement grouping, noise and resource analysis.

## References and current dependency information

The project metadata uses recent release versions surfaced by the project/PyPI sources on **11 November 2026**: PyTorch 2.15.0, NumPy 2.5.4, SciPy 1.18.1, Matplotlib 3.11.2, Streamlit 1.67.0, pytest 9.2.0, and optional Qiskit 2.6.x. Version ranges in `pyproject.toml` allow compatible patch releases while avoiding unbounded major-version changes. Check the official installers before choosing a CUDA wheel.

- PyTorch install selector: <https://docs.pytorch.org/get-started/locally/>
- NumPy releases: <https://pypi.org/project/numpy/>
- SciPy releases: <https://pypi.org/project/scipy/>
- Matplotlib releases: <https://pypi.org/project/matplotlib/>
- Streamlit release notes: <https://docs.streamlit.io/develop/quick-reference/release-notes>
- Qiskit `SparsePauliOp`: <https://qiskit.qotlabs.org/docs/api/qiskit/qiskit.quantum_info.SparsePauliOp>

## Disclaimer

The package is intended for learning, prototyping and reproducible numerical experiments. It is not a substitute for validated computational physics software, peer review, or experimental characterization.
