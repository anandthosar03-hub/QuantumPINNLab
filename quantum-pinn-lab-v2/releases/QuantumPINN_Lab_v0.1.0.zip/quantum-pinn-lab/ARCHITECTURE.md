# System design — QuantumPINN Lab v0.1

## 1. Scope and system boundary

The first release is deliberately a **1D dimensionless research workbench**. Its core scientific task is the low-lying spectrum and eigenfunctions of a bounded one-dimensional Hamiltonian. It also exposes one independent time-propagation method and one finite-dimensional quantum-computing representation.

### Functional requirements

1. Define a 1D potential with numeric parameters.
2. Solve for the first `k` stationary eigenstates with a neural trial wavefunction.
3. Enforce Dirichlet boundary conditions exactly.
4. Estimate state energy and report normalization, orthogonality and PDE residual.
5. Compare with an independent finite-difference eigensolver.
6. Calculate physical observables in the project's dimensionless convention.
7. Propagate an initial wavepacket in time and monitor probability conservation.
8. Convert a finite-grid Hamiltonian into a qubit Pauli expansion and optionally export to Qiskit.
9. Export numerical arrays and summary metrics.

### Non-functional requirements

- Reproducible random seeds and explicit solver configuration.
- CPU fallback; CUDA auto-detection; float32 training for low memory use.
- Separate physics, ML, UI and quantum-integration layers.
- Unit tests for mathematical invariants, not merely UI behavior.
- No cloud service, paid API, database or external runtime is required.

## 2. Layered architecture

| Layer | Components | Responsibility |
|---|---|---|
| Presentation | Streamlit, CLI | Inputs, progress, plots, result export |
| Application | `solve_stationary`, dynamics orchestration | Workflow coordination and diagnostics |
| ML solver | `WavefunctionPINN`, autograd residual, optimizer | Neural representation and physics-informed refinement |
| Physics | potential registry, FD eigensolver, observables, CN propagator | Equation definitions and independent numerical calculations |
| Quantum bridge | grid Hamiltonian, Pauli decomposition, Qiskit adapter | Matrix-to-qubit operator representation |
| Verification | pytest | Boundary, spectrum, norm-conservation and Pauli-reconstruction tests |

## 3. Data flow: stationary eigenstate

```mermaid
flowchart TD
  A[Choose potential and domain] --> B[Build FD Hamiltonian]
  B --> C[Compute reference eigenpairs]
  C --> D[Initialize one neural state]
  D --> E{FD warm start enabled?}
  E -- Yes --> F[Fit network to reference eigenvector]
  E -- No --> G[Random network initialization]
  F --> H[Sample collocation points]
  G --> H
  H --> I[Autograd: first and second derivatives]
  I --> J[Schrodinger residual]
  J --> K[Add normalization and orthogonality losses]
  K --> L[Optimize network and trainable energy]
  L --> M[Evaluate dense diagnostic grid]
  M --> N[Energy, residual, norm and overlap metrics]
  N --> O[Compare with reference and export]
```

Excited states are trained sequentially. Earlier predicted states are frozen and used in overlap penalties. The finite-difference calculation is an explicit baseline and optional warm-start source; it is not hidden from the user.

## 4. Mathematical model

The spatial domain is symmetric and finite, `[-L,L]`; `ψ(-L)=ψ(L)=0`. The Hamiltonian is

`H = -½ d²/dx² + V(x)`.

The neural model receives normalized coordinate `ξ=x/L` (equivalent affine scaling for any symmetric interval) and outputs

`ψθ(x) = (1-ξ²) Nθ(ξ)`.

The multiplicative envelope satisfies both endpoint conditions exactly. For a candidate energy `Eθ`, the residual is

`rθ(x) = -½ ψθ''(x) + V(x) ψθ(x) - Eθ ψθ(x)`.

The objective is a weighted sum of mean-square residual, normalization penalty, overlaps with earlier states, and a weak reference-energy anchor. The latter stabilizes this first prototype; a future fully variational/reference-free training mode should replace it with a Rayleigh-quotient or spectral-ordering strategy.

## 5. Numerical reference

For grid spacing `h`, the three-point kinetic stencil for `-½ d²/dx²` has diagonal `1/h²` and adjacent entries `-1/(2h²)`. The resulting real symmetric tridiagonal matrix is diagonalized with SciPy's `eigh_tridiagonal`. Its eigenvectors are normalized by trapezoidal quadrature.

The reference method has its own discretization error. Grid refinement is required for reported benchmark numbers.

## 6. Time-dependent solver

The Crank–Nicolson step is

`(I + i Δt H/2) ψ(t+Δt) = (I - i Δt H/2) ψ(t)`.

A sparse LU factorization of the left-hand matrix is reused for every step when the time-independent potential is fixed. The app reports norm drift and computes `J=Im(ψ* ∂ψ/∂x)` in the same dimensionless units.

## 7. Quantum-computing interface

A finite-difference Hamiltonian of dimension `2ⁿ` is treated as an operator on `n` qubits. It is decomposed as

`H = Σ_P c_P P`, `c_P = Tr(PH)/2ⁿ`,

where `P` ranges over all `n`-qubit Pauli strings. Small coefficients can be filtered by a user-selected tolerance. The adapter creates a Qiskit `SparsePauliOp` from the retained terms.

This direct encoding is exact up to floating-point/tolerance error, but it is exponentially large in the worst case. A low Pauli count is not guaranteed, and this interface does not by itself provide a quantum speedup. Structured encodings, measurement grouping and VQE resource estimates are future research tasks.

## 8. Error handling and scientific guardrails

- Reject invalid domains, negative width/softening and non-finite parameters.
- Fail clearly if CUDA is requested but unavailable.
- Detect zero/invalid wavefunction norm.
- Validate Hermiticity and power-of-two dimension in Pauli mapping.
- Report PINN-vs-FD error, not just the training loss.
- Keep the physical units explicit: all current calculations are dimensionless with `ℏ=m=1`.
- Do not interpret a converged 1D model as a calibrated multi-band, many-body or open-system device simulation.

## 9. Extension interfaces

- Add potential classes through matching NumPy and torch evaluators.
- Add PDE terms in `solvers/` without coupling to Streamlit.
- Add a new reference solver behind a common result schema.
- Add VQE experiments under `quantum/`, preserving the Pauli export interface.
- Add material units and effective-mass scales as a separate unit-conversion module; do not mix SI constants into the current dimensionless core.
