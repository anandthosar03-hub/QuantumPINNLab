# Project plan — AI-Based Schrödinger Equation Solver

## Project objective

Build a reproducible scientific-ML platform that approximates quantum wavefunctions and energy eigenvalues using physics-informed neural networks, quantifies its own errors against trusted numerical methods, simulates wavepacket dynamics, and exports discretized Hamiltonians into qubit operators for quantum-computing experiments.

## Problem statement

Numerical quantum-mechanics workflows often require a domain-specific discretization and a fresh numerical solve for each potential. A neural surrogate can potentially amortize repeated solves, explore parameter families, and support inverse design, but only if physical constraints and independent numerical validation are built into the system. A PINN should not be treated as correct merely because its training loss decreases.

**Research question:** Under what conditions can a boundary-constrained PINN reproduce low-lying eigenstates of 1D quantum Hamiltonians with controlled energy error, residual, normalization and orthogonality, and can that representation be extended to parameter sweeps and quantum-Hamiltonian experiments?

## Target applications and responsible scope

| Quantum problem | What this project can investigate | What must be added before real deployment |
|---|---|---|
| Semiconductor quantum wells | Bound-state energies, confinement probability, wavefunction leakage | Material-specific effective mass, band offsets, calibrated layer geometry and SI conversion |
| Quantum dots / nanostructures | 1D confinement prototypes, parameter sensitivity | 2D/3D geometry, realistic potentials, multi-band effects and validated boundary conditions |
| Tunneling devices | Barrier transmission, time-dependent wavepacket reflection/transmission | Device-specific bias, interfaces, contact models, decoherence and open boundaries |
| Molecular / atomic models | Soft-Coulomb toy spectra and state structure | Accurate dimensionality, many-electron interactions, exchange/correlation and basis convergence |
| Quantum computing | Encode a finite-grid Hamiltonian as Pauli strings; prepare VQE experiments | Efficient encoding, Pauli grouping, circuit ansatz, noise model, shot/resource estimates and backend validation |
| Inverse design | Planned optimization of well/barrier parameters for target energies or level splitting | Differentiable parameter-conditioned solver and uncertainty analysis |

This release is a research prototype. It is not a certified semiconductor simulator, molecular solver, quantum-processor controller, or substitute for experimental measurement.

## System deliverables

1. **Physics core:** dimensionless Hamiltonian and potential registry with NumPy/PyTorch implementations.
2. **PINN model:** fully connected tanh network with exact Dirichlet boundary envelope and automatic second derivatives.
3. **Training engine:** sequential low-lying eigenstate fitting, optional finite-difference warm start, residual/normalization/orthogonality/energy-anchor losses.
4. **Reference engine:** independent tridiagonal finite-difference eigensolver.
5. **Diagnostics:** energy deviation, residual RMS, norm, overlap, wavefunction plots and quantum observables.
6. **Dynamics engine:** sparse Crank–Nicolson wavepacket time evolution and probability current.
7. **Quantum bridge:** finite-grid Hamiltonian to Pauli expansion, reconstruction check and optional Qiskit adapter.
8. **Interfaces:** Streamlit app, command-line runner, compressed numerical exports.
9. **Quality:** unit tests, reproducible configurations and documented limitations.

## 8-week implementation and research schedule

| Week | Engineering/research work | Acceptance evidence |
|---|---|---|
| 1 — Physics baseline | Derive dimensionless equation; implement potentials and FD reference; confirm harmonic oscillator spectrum | First 3 harmonic energies agree with analytic `n+½` within a grid-refinement tolerance; normalized/orthogonal states |
| 2 — PINN architecture | Build boundary-constrained MLP, autograd derivatives, one-state residual loss | Boundary values numerically zero; ground-state residual decreases on a held-out grid |
| 3 — Excited states | Add normalization, sequential orthogonality and energy parameter; warm start and reference-free toggle | First 3 states show expected node count/parity and bounded overlap |
| 4 — Validation and observables | Add convergence sweeps, error reports, `⟨x⟩`, `Δx`, `Δp`, energy decomposition | Results compared over at least 3 grids and 3 random seeds; errors documented |
| 5 — Dynamics | Implement Crank–Nicolson packet propagation, current and transmission/reflection diagnostics | Norm drift stays small under `dt` refinement; barrier-tunneling experiment reproducible |
| 6 — Quantum computing | Encode small-grid Hamiltonian with Pauli strings; optional Qiskit object; reconstruction test | Relative matrix reconstruction error below numerical tolerance for small systems |
| 7 — Application shell | Build Streamlit panels, CLI, result export and experiment presets | A new user can run a documented harmonic/double-well experiment from a fresh environment |
| 8 — Research report | Benchmark PINN vs FD cost/accuracy, document failure cases, produce plots and reproducibility manifest | Technical report includes equations, hyperparameters, convergence plots, limitations and raw outputs |

## Success metrics

The project should report metrics rather than promise a single universal accuracy target:

- Relative energy error: `|E_PINN − E_FD| / max(|E_FD|, ε)`.
- PDE residual RMS on a held-out dense grid.
- Norm error: `|∫|ψ|²dx − 1|`.
- Maximum pairwise overlap: `max_{i≠j}|∫ψᵢ*ψⱼdx|`.
- Wavefunction fidelity after phase/sign alignment: `|⟨ψ_PINN|ψ_FD⟩|²`.
- Expected node count and symmetry/parity.
- Time-evolution norm drift and grid/time-step convergence.
- Pauli reconstruction error `||H−H_Pauli||_F / ||H||_F`.
- Runtime and peak memory measured separately for CPU and GPU.

A proposed milestone target for a smooth harmonic potential is energy error below 1% for the first few states after tuning, but this is a project target, not an already-established guarantee for all potentials. Discontinuous square wells and higher excited states are expected to be harder.

## Key risks and mitigations

| Risk | Why it matters | Mitigation in this release / next step |
|---|---|---|
| Excited-state collapse | Orthogonality alone can still converge to the wrong mode | Sequential training, reference warm start, node/parity checks; next add Rayleigh-Ritz subspace training |
| PINN spectral bias | Smooth networks struggle with oscillatory high states | Increase width/depth, Fourier features, curriculum and adaptive sampling |
| Discontinuous potentials | Smooth tanh models approximate sharp interfaces poorly | Compare against FD; next use domain-decomposed PINNs/interface conditions |
| False confidence from training loss | Low training loss need not mean low global residual | Independent dense-grid residual and FD energy comparison |
| Domain truncation | Bound-state tails may hit the artificial boundary | Domain-size convergence tests; adaptive domain selection |
| Quantum mapping explosion | A general `n`-qubit operator has up to `4ⁿ` Pauli terms | Keep initial grid small; exploit Hamiltonian structure and locality before scaling |
| Physical model mismatch | Dimensionless 1D potential is not a real material model | Add effective-mass/material parameters, unit conversion and independent validation |

## Next high-value feature after v0.1

**Parameter-conditioned inverse design.** Train a model with both coordinate `x` and potential parameters as inputs, then optimize parameters against targets such as a desired ground-state energy, localization width, or double-well tunnel splitting. Keep the finite-difference solver as ground truth during training and evaluate optimization on held-out parameter combinations. This is the step that turns the current solver from a single-potential demonstrator into a reusable design tool.
